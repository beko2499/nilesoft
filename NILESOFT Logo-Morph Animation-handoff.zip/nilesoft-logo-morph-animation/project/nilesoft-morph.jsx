// NILESOFT logo-morph — render layer (requires animations-v3.jsx, tweaks-panel.jsx, nilesoft-core.js, nilesoft-tracks.js).
const NS = window.NS;
const { IVORY, INK, DEEP, MIST, STONE, COPPER, PANEL, LINE, THUMB, TXT, clamp01 } = NS;

function El({ s, z, ov, children }) {
  if (!s || (s.o != null && s.o <= 0.004)) return null;
  const st = {
    position: 'absolute', left: (s.x - s.w / 2) + 'px', top: (s.y - s.h / 2) + 'px',
    width: s.w + 'px', height: s.h + 'px', boxSizing: 'border-box',
    opacity: s.o == null ? 1 : clamp01(s.o), zIndex: z || 1,
    background: s.f && s.f !== 'none' ? s.f : 'transparent'
  };
  if (s.r) st.transform = 'rotate(' + s.r + 'deg)';
  if (s.clip) st.clipPath = 'polygon(' + s.clip.map(p => p[0] + '% ' + p[1] + '%').join(',') + ')';
  else if (s.rx) st.borderRadius = s.rx + 'px';
  if (s.sw) st.border = s.sw + 'px solid ' + (s.sc || INK);
  if (ov) st.overflow = 'hidden';
  return <div style={st}>{children}</div>;
}

const bar = (key, l, t, w, h, c, o, r) => o <= 0.004 ? null :
  <div key={key} style={{ position: 'absolute', left: l, top: t, width: w, height: h, background: c, opacity: o, borderRadius: r == null ? 4 : r }} />;

// Interior dressing of the six cards, per era, crossfaded by cue-keyed weights.
function guts(i, T, q) {
  const F = NS.fade, out = [];
  const wLand = i < 3 ? F(T, q.L + .90, q.L + 1.15, q.S + .05, q.S + .40) : 0;
  const wProd = F(T, q.S + .45, q.S + .80, q.M + .05, q.M + .45);
  const wRow = i < 2 ? F(T, q.M + .45, q.M + .80, q.W + .05, q.W + .40) : 0;
  const wNode = (i === 0 || i === 2 || i === 5) ? F(T, q.W + .45, q.W + .75, q.D + .05, q.D + .40) : 0;
  const wMod = F(T, q.D + .45, q.D + .80, q.V + .05, q.V + .38);
  const wWire = (i === 0 || i === 1 || i === 5) ? F(T, q.V + .40, q.V + .62, q.X + .05, q.X + .35) : 0;
  const wGrid = i === 4 ? F(T, q.X + .75, q.X + 1.0, q.R + .05, q.R + .28) : 0;
  if (wLand > 0) {
    out.push(bar('la', '24%', '38%', '50%', 9, TXT, wLand));
    out.push(bar('lb', '24%', '56%', '36%', 8, LINE, wLand));
  }
  if (wProd > 0) {
    out.push(<div key="pt" style={{ position: 'absolute', left: '7%', top: '6%', width: '86%', height: '52%', background: THUMB, borderRadius: 8, opacity: wProd, overflow: 'hidden' }}>
      {i > 0 && <div style={{
        position: 'absolute', left: '22%', top: '22%', width: '56%', height: '56%', background: INK,
        clipPath: i % 2 ? 'polygon(0 0,26% 0,100% 100%,74% 100%)' : 'polygon(100% 0,74% 0,0 100%,26% 100%)'
      }} />}
    </div>);
    out.push(bar('pa', '8%', '68%', '46%', 11, STONE, wProd));
    out.push(bar('pb', '8%', '80%', '30%', 9, LINE, wProd));
    if (i > 0) out.push(bar('pc', '70%', '78%', '22%', 12, STONE, wProd));
  }
  if (wRow > 0) {
    out.push(<div key="ra" style={{ position: 'absolute', left: '5%', top: '18%', width: '17%', height: '64%', background: THUMB, borderRadius: 6, opacity: wRow }} />);
    out.push(bar('rb', '27%', '28%', '42%', 9, STONE, wRow));
    out.push(bar('rc', '27%', '52%', '30%', 8, LINE, wRow));
  }
  if (wNode > 0) out.push(bar('na', '41%', '41%', '18%', '18%', STONE, wNode, 3));
  if (wMod > 0) {
    if (i < 3) {
      out.push(bar('ma', '8%', '14%', '34%', 10, STONE, wMod));
      const lx = i === 0 ? '30%' : i === 1 ? '26%' : '8%';
      out.push(bar('mb', lx, '42%', '46%', 9, TXT, wMod));
      out.push(bar('mc', lx, '62%', '36%', 9, LINE, wMod));
      if (i === 2) out.push(bar('md', '8%', '80%', '60%', 9, LINE, wMod));
    } else if (i < 5) {
      out.push(bar('ma', '12%', '18%', '40%', 9, TXT, wMod));
      out.push(bar('mb', '12%', '44%', '46%', '26%', INK, wMod, 4));
      out.push(bar('mc', '12%', '80%', '26%', 8, LINE, wMod));
    } else {
      const hs = [22, 30, 26];
      hs.forEach((h, j) => out.push(<div key={'ch' + j} style={{
        position: 'absolute', left: (58 + j * 7) + '%', bottom: '8%', width: '4.2%',
        height: (h * wMod) + '%', background: j === 1 ? STONE : MIST, borderRadius: 3, opacity: wMod
      }} />));
    }
  }
  if (wWire > 0) {
    out.push(bar('wa', '8%', i === 5 ? '30%' : '10%', i === 5 ? '20%' : '38%', 8, STONE, wWire * .8));
    if (i !== 5) out.push(bar('wb', '8%', '20%', '26%', 7, STONE, wWire * .6));
  }
  if (wGrid > 0) {
    [['56%', '30%'], ['30%', '56%'], ['56%', '56%']].forEach((p, j) =>
      out.push(bar('g' + j, p[0], p[1], '14%', '14%', STONE, wGrid, 2)));
  }
  return out.length ? out : null;
}

function Check({ s, z }) {
  if (!s || s.o <= 0.01) return null;
  const p = clamp01(s.p), L = 30;
  return <svg width="40" height="40" viewBox="0 0 40 40" style={{
    position: 'absolute', left: s.x - 20, top: s.y - 20, opacity: clamp01(s.o),
    transform: 'scale(' + s.k + ')', zIndex: z
  }}>
    <circle cx="20" cy="20" r="17" fill={IVORY} stroke={INK} strokeWidth="2.5" />
    <polyline points="12,21 18,27 29,13" fill="none" stroke={INK} strokeWidth="3"
      strokeLinecap="round" strokeLinejoin="round"
      strokeDasharray={L} strokeDashoffset={(1 - p) * L} />
  </svg>;
}

function Wordmark({ T, q, on }) {
  const t0 = q.R + 1.02;
  if (!on || T < t0) return null;
  const ls = NS.lerp(0.55, 0.38, NS.MOTION.move(clamp01((T - t0) / 0.45)));
  return <div style={{
    position: 'absolute', left: 0, right: 0, top: 764, textAlign: 'center', zIndex: 26,
    fontFamily: "'Archivo',sans-serif", fontWeight: 600, fontSize: '60px',
    letterSpacing: ls + 'em', textIndent: ls + 'em', color: DEEP
  }}>
    {'NILESOFT'.split('').map((c, i) => {
      const p = NS.MOTION.draw(clamp01((T - t0 - i * .04) / 0.32));
      return <span key={i} style={{ opacity: p, display: 'inline-block', transform: 'translateY(' + ((1 - p) * 12) + 'px)' }}>{c}</span>;
    })}
  </div>;
}

function Piece({ tw }) {
  const { T, CUES } = window.useComposition();
  const built = React.useMemo(() => NS.buildTracks(CUES), [CUES]);
  const q = built.cue, S = {};
  for (const k in built.tr) S[k] = NS.ev(built.tr[k], T);

  if (T < q.L) { // entry fade riding each piece's arrival
    const ef = t0 => NS.MOTION.draw(clamp01((T - t0) / 0.22));
    S.bar.o *= ef(q.A + .05); S.sqt.o *= ef(q.A + .10); S.sbar.o *= ef(q.A + .15);
    S.sqc.o *= ef(q.A + .25); S.tick.o *= ef(q.A + .35);
  }
  // flow rail + copper trail behind the workflow runner
  const flowO = NS.fade(T, q.W + .25, q.W + .42, q.D + .05, q.D + .35);
  const rail = { x: 1070, y: 500, w: 1040, h: 5, f: STONE, o: flowO };
  const px = Math.min(T < q.D ? S.sqc.x : 1420, 1420);
  const prog = {
    x: (550 + px) / 2, y: 500, w: Math.max(0, px - 550), h: 5, f: COPPER,
    o: flowO * NS.MOTION.draw(clamp01((T - q.W - .32) / .08))
  };
  // end-of-loop diagonal wipe back to paper
  const wp = NS.MOTION.move(clamp01((T - q.H - .55) / .41));
  const wipeA = 150 - 202 * wp;
  if (!tw.wordmark) S.dash.o = 0;

  let scene = 'Assemble';
  for (const n in CUES) if (T >= CUES[n]) scene = n;
  const b = (t0, w) => Math.max(0, 1 - Math.abs(T - t0) / w);
  const drift = 1 + 0.005 * Math.sin(T * 0.6 + 0.8)
    + 0.012 * Math.pow(b(q.A + .92, .3), 2) + 0.012 * Math.pow(b(q.R + 1.06, .3), 2);

  return <div data-screen-label={scene + ' · ' + T.toFixed(1) + 's'}
    style={{ position: 'absolute', inset: 0, overflow: 'hidden', background: IVORY, fontFamily: "'Archivo',sans-serif" }}>
    <div style={{ position: 'absolute', inset: 0, transform: 'scale(' + drift + ')', transformOrigin: '50% 50%' }}>
      <El s={S.hero} z={2} />
      <El s={S.frame} z={3} />
      <El s={S.tl1} z={4} /><El s={S.tl2} z={4} />
      <El s={S.nav1} z={5} /><El s={S.nav2} z={5} /><El s={S.nav3} z={5} />
      <El s={rail} z={6} />
      <El s={prog} z={6} />
      {[1, 2, 3, 4, 5, 6].map(i => <El key={i} s={S['c' + i]} z={8} ov>{guts(i - 1, T, q)}</El>)}
      <El s={S.bar} z={12} />
      <El s={S.sbar} z={13} />
      <El s={S.sqt} z={14} />
      <El s={S.dot1} z={16} /><El s={S.dot2} z={16} /><El s={S.dot3} z={16} />
      <Check s={S.chk1} z={18} /><Check s={S.chk2} z={18} /><Check s={S.chk3} z={18} />
      <El s={S.sqc} z={20} />
      <El s={S.tick} z={21} />
      <El s={S.pulse} z={24} />
      <Wordmark T={T} q={q} on={tw.wordmark} />
      <El s={S.dash} z={27} />
    </div>
    {tw.loopWipe && wp > 0.001 && <div style={{
      position: 'absolute', inset: 0, background: IVORY, zIndex: 90,
      clipPath: 'polygon(' + wipeA + '% 0%,300% 0%,300% 100%,' + (wipeA + 49.4) + '% 100%)'
    }} />}
  </div>;
}

function NilesoftMorph() {
  const [tw, setTweak] = window.useTweaks(window.TWEAK_DEFAULTS);
  return <div style={{ position: 'fixed', inset: 0, background: IVORY, display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
    <window.CompositionStage width={1920} height={1080} bg={IVORY}
      scenes={window.OM_SCENES} playback={window.OM_PLAYBACK}>
      <Piece tw={tw} />
    </window.CompositionStage>
    <window.TweaksPanel>
      <window.TweakSection label="Motion" />
      <window.TweakToggle label="Motion editor" value={tw.motionEditor} onChange={v => setTweak('motionEditor', v)} />
      <window.TweakSection label="Ending" />
      <window.TweakToggle label="Wordmark at end" value={tw.wordmark} onChange={v => setTweak('wordmark', v)} />
      <window.TweakToggle label="Loop wipe-out" value={tw.loopWipe} onChange={v => setTweak('loopWipe', v)} />
    </window.TweaksPanel>
  </div>;
}
window.NilesoftMorph = NilesoftMorph;
