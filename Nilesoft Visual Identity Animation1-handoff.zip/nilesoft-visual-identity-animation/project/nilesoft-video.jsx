// Nilesoft identity montage — composition for animations-v3 engine. 1080×1920.
const { CompositionStage, useComposition, Shot, Easing, animate, clamp } = window;
const { useTweaks, TweaksPanel, TweakSection, TweakColor, TweakText, TweakToggle } = window;

const PAPER = '#FAFAF8', INK = '#141413', PAPER_D = '#0C0C0B', INK_D = '#F5F5F1';
const MIST = '#DEDED8', STONE = '#8A8A84', GRAPHITE = '#3A3A36';
const CP = "'Chakra Petch', sans-serif";
const MONO = "500 1em ui-monospace, Menlo, monospace";
// The three motion helpers — no easing outside these.
const M = {
  enter: (T, s, e) => animate({ from: 0, to: 1, start: s, end: e, ease: Easing.easeOutCubic })(T),
  draw:  (T, s, e) => animate({ from: 0, to: 1, start: s, end: e, ease: Easing.easeInOutQuart })(T),
  pop:   (T, s, e) => animate({ from: 0, to: 1, start: s, end: e, ease: Easing.easeOutBack })(T),
};
// Diagonal wipe matching the mark's slash angle (0.9 dx per dy).
const SLANT = 0.9 * 1920;
function wipeClip(p) {
  const xt = -(SLANT + 20) + p * (1080 + SLANT + 40);
  return `polygon(0 0, ${xt}px 0, ${xt + SLANT}px 1920px, 0 1920px)`;
}

// Mark geometry: 252×160 viewBox, squares 36.
const SLASH = '0,0 58,0 202,160 144,160';
const STEM_MID = '170,70 228,70 252,96.7 252,126 220.4,126';
const STEM_TAIL = '214,134 244,134 252,142.9 252,160 237.4,160';

function Sq({ x, y, cx, cy, scale, o, fill }) {
  return <rect x={x} y={y} width="36" height="36" fill={fill} opacity={o}
    transform={`translate(${cx} ${cy}) scale(${scale}) translate(${-cx} ${-cy})`} />;
}

function Mark({ ink, accent, T, C, idp }) {
  const p = M.draw(T, C.Slash + 0.2, C.Slash + 1.55);
  const h = 160 * p;
  const ghosts = [
    { x: 80, y: 40, a: C.Grid + 0.45, b: C.Grid + 0.6 },
    { x: 144, y: 96, a: C.Grid + 0.66, b: C.Grid + 0.8 },
    { x: 40, y: 72, a: C.Grid + 0.88, b: C.Grid + 1.0 },
  ];
  const sTR = 0.3 + 0.7 * M.pop(T, C.Grid + 0.72, C.Grid + 1.12), oTR = M.enter(T, C.Grid + 0.72, C.Grid + 0.84);
  const sBL = 0.3 + 0.7 * M.pop(T, C.Grid + 1.06, C.Grid + 1.46), oBL = M.enter(T, C.Grid + 1.06, C.Grid + 1.18);
  const eMid = M.enter(T, C.Lock + 0.15, C.Lock + 0.85);
  const eTail = M.enter(T, C.Lock + 0.4, C.Lock + 1.1);
  const brO = M.enter(T, C.Lock + 1.25, C.Lock + 1.4) * (1 - M.enter(T, C.Lock + 1.85, C.Lock + 2.07));
  const brS = 1.14 - 0.14 * M.pop(T, C.Lock + 1.25, C.Lock + 1.65);
  const lblO = 0.5 * M.enter(T, C.Grid + 1.35, C.Grid + 1.7) * (1 - M.enter(T, C.Lock + 0.65, C.Lock + 1.0));
  const drawEnd = C.Slash + 1.55;
  const cursorOn = p > 0.015 && T < drawEnd + 0.3;
  const cursorO = T < drawEnd ? 1 : 1 - M.enter(T, drawEnd, drawEnd + 0.28);
  return (
    <svg viewBox="0 0 252 160" style={{ position: 'absolute', inset: 0, width: '100%', height: '100%', overflow: 'visible', display: 'block' }}>
      <defs><clipPath id={idp + 'draw'}><rect x="-4" y="-4" width="260" height={h + 4} /></clipPath></defs>
      {ghosts.map((g, i) => (
        <rect key={i} x={g.x} y={g.y} width="36" height="36" fill={accent} opacity={T >= g.a && T <= g.b ? 0.2 : 0} />
      ))}
      <Sq x={188} y={0} cx={206} cy={18} scale={sTR} o={oTR} fill={ink} />
      <Sq x={0} y={124} cx={18} cy={142} scale={sBL} o={oBL} fill={ink} />
      <g clipPath={`url(#${idp}draw)`}><polygon points={SLASH} fill={ink} /></g>
      {cursorOn ? <rect x={0.9 * h + 22} y={h - 8} width="14" height="14" fill={accent} opacity={cursorO} /> : null}
      <g opacity={eMid} transform={`translate(${-30.8 * (1 - eMid)} ${-34.2 * (1 - eMid)})`}><polygon points={STEM_MID} fill={ink} /></g>
      <g opacity={eTail} transform={`translate(${-24.1 * (1 - eTail)} ${-26.7 * (1 - eTail)})`}><polygon points={STEM_TAIL} fill={ink} /></g>
      <g opacity={brO} stroke={accent} strokeWidth="2.5" fill="none" transform={`translate(126 80) scale(${brS}) translate(-126 -80)`}>
        <path d="M 2,-16 L -16,-16 L -16,2" /><path d="M 250,-16 L 268,-16 L 268,2" />
        <path d="M 268,158 L 268,176 L 250,176" /><path d="M 2,176 L -16,176 L -16,158" />
      </g>
      <text x="0" y="-16" fill={ink} opacity={lblO} style={{ font: '500 10px ui-monospace, Menlo, monospace', letterSpacing: '0.18em' }}>NS-01 · 252×160 · GRID 36</text>
    </svg>
  );
}

// Shared lockup: mark + wordmark. animated=true plays the invert-scene choreography.
function Lockup({ T, C, ink, accent, idp, animated }) {
  const my = animated ? -70 * M.draw(T, C.Invert + 1.0, C.Invert + 1.9) : -70;
  const sp = animated ? Math.sin(Math.PI * clamp((T - (C.Lock + 1.3)) / 0.45, 0, 1)) * 0.028 : 0;
  const track = animated ? 40 * (1 - M.draw(T, C.Invert + 1.25, C.Invert + 2.4)) : 0;
  const cam = animated ? 1.06 - 0.06 * M.draw(T, C.Grid, C.Lock - 0.2) : 1;
  return (
    <div style={{ position: 'absolute', inset: 0, transform: `scale(${cam})` }}>
      <div style={{ position: 'absolute', left: 260, top: 652, width: 560, height: 355.5, transform: `translateY(${my}px) scale(${1 + sp})` }}>
        <Mark ink={ink} accent={accent} T={T} C={C} idp={idp} />
      </div>
      <div style={{ position: 'absolute', left: 0, right: 0, top: 992, textAlign: 'center', fontFamily: CP, fontWeight: 600, fontSize: 84, color: ink, lineHeight: 1.2, whiteSpace: 'nowrap' }}>
        {'NILESOFT'.split('').map((ch, i) => {
          const o = animated ? M.enter(T, C.Invert + 1.25 + i * 0.075, C.Invert + 1.8 + i * 0.075) : 1;
          return <span key={i} style={{ display: 'inline-block', opacity: o, transform: `translateX(${(i - 3.5) * track}px)`, marginRight: i < 7 ? '0.42em' : 0 }}>{ch}</span>;
        })}
      </div>
    </div>
  );
}

function ChapterTag({ text, o, accent }) {
  return (
    <div style={{ position: 'absolute', left: 90, top: 170, display: 'flex', alignItems: 'center', gap: 18, opacity: o }}>
      <div style={{ width: 14, height: 14, background: accent }} />
      <div style={{ font: MONO, fontSize: 26, letterSpacing: '0.3em', color: STONE, whiteSpace: 'nowrap' }}>{text}</div>
    </div>
  );
}

function TypePanel({ T, C, accent }) {
  const wip = wipeClip(M.draw(T, C.Type, C.Type + 0.9));
  const drift = 14 - 28 * M.draw(T, C.Type + 0.2, C.Color + 0.2);
  const e = (s) => M.enter(T, C.Type + s, C.Type + s + 0.6);
  const rise = (v) => `translateY(${26 * (1 - v)}px)`;
  const alpha = ['ABCDEFGHIJKLM', 'NOPQRSTUVWXYZ', '0123456789 —&'];
  const weights = [['Medium', 500], ['SemiBold', 600], ['Bold', 700]];
  return (
    <div style={{ position: 'absolute', inset: 0, clipPath: wip, background: PAPER_D }}>
      <div style={{ position: 'absolute', inset: 0, opacity: 0.5, backgroundImage: 'repeating-linear-gradient(0deg, rgba(245,245,241,0.05) 0 1px, transparent 1px 54px), repeating-linear-gradient(90deg, rgba(245,245,241,0.05) 0 1px, transparent 1px 54px)' }} />
      <div style={{ position: 'absolute', inset: 0, transform: `translateY(${drift}px)` }}>
        <ChapterTag text="02 / TYPEFACE" o={e(0.45)} accent={accent} />
        <div style={{ position: 'absolute', left: 76, top: 240, fontFamily: CP, fontWeight: 600, fontSize: 430, lineHeight: 1, color: INK_D, opacity: e(0.55), transform: rise(e(0.55)) }}>Aa</div>
        <div style={{ position: 'absolute', left: 90, top: 780, font: MONO, fontSize: 24, letterSpacing: '0.22em', color: STONE, whiteSpace: 'nowrap', opacity: e(0.75), transform: rise(e(0.75)) }}>CHAKRA PETCH — GEOMETRIC SANS</div>
        <div style={{ position: 'absolute', left: 90, top: 890, fontFamily: CP, fontWeight: 500, fontSize: 46, lineHeight: 1.55, letterSpacing: '0.12em', color: 'rgba(245,245,241,0.92)', whiteSpace: 'nowrap', opacity: e(0.9), transform: rise(e(0.9)) }}>
        {alpha.map((l, i) => <div key={i}>{l}</div>)}
        </div>
      <div style={{ position: 'absolute', left: 90, top: 1250, opacity: e(1.1), transform: rise(e(1.1)) }}>
          {weights.map(([n, w], i) => (
            <div key={i} style={{ fontFamily: CP, fontWeight: w, fontSize: 42, lineHeight: 1.7, color: INK_D, whiteSpace: 'nowrap' }}>{n} <span style={{ color: STONE }}>{w}</span></div>
          ))}
        </div>
      </div>
    </div>
  );
}

function ColorPanel({ T, C, accent }) {
  const wip = wipeClip(M.draw(T, C.Color, C.Color + 0.9));
  const drift = 14 - 28 * M.draw(T, C.Color + 0.2, C.Apps + 0.2);
  const bands = [
    ['PAPER', PAPER, INK, false], ['MIST', MIST, INK, false], ['STONE', STONE, INK, false],
    ['GRAPHITE', GRAPHITE, INK_D, false], ['INK', '#141413', INK_D, true],
  ];
  return (
    <div style={{ position: 'absolute', inset: 0, clipPath: wip, background: PAPER_D }}>
      <div style={{ position: 'absolute', inset: 0, transform: `translateY(${drift}px)` }}>
        <ChapterTag text="03 / COLOR" o={M.enter(T, C.Color + 0.45, C.Color + 1.05)} accent={accent} />
        <div style={{ position: 'absolute', left: 90, top: 400, width: 900, display: 'grid', gap: 12 }}>
          {bands.map(([name, bg, fg, border], i) => {
            const be = M.draw(T, C.Color + 0.35 + i * 0.13, C.Color + 0.95 + i * 0.13);
            return (
              <div key={i} style={{ height: 190, background: bg, border: border ? '1px solid rgba(245,245,241,0.16)' : 'none', clipPath: `inset(0 ${(1 - be) * 100}% 0 0)`, display: 'flex', alignItems: 'center', justifyContent: 'space-between', padding: '0 44px' }}>
                <div style={{ fontFamily: CP, fontWeight: 600, fontSize: 34, letterSpacing: '0.14em', color: fg }}>{name}</div>
                <div style={{ font: MONO, fontSize: 26, letterSpacing: '0.12em', color: fg, opacity: 0.72 }}>{bg.toUpperCase()}</div>
              </div>
            );
          })}
        </div>
      </div>
    </div>
  );
}

function AppsPanel({ T, C, accent, cardName }) {
  const wip = wipeClip(M.draw(T, C.Apps, C.Apps + 0.9));
  const drift = 16 - 32 * M.draw(T, C.Apps + 0.2, C.Outro + 0.3);
  const item = (s) => {
    const v = M.enter(T, C.Apps + s, C.Apps + s + 0.7);
    return { opacity: v, transform: `translate(${-36 * (1 - v)}px, ${-40 * (1 - v)}px)` };
  };
  const lbl = { font: MONO, fontSize: 20, letterSpacing: '0.28em', color: STONE, whiteSpace: 'nowrap' };
  const shadow = '0 24px 70px rgba(0,0,0,0.5)';
  return (
    <div style={{ position: 'absolute', inset: 0, clipPath: wip, background: PAPER_D }}>
      <div style={{ position: 'absolute', inset: 0, opacity: 0.5, backgroundImage: 'repeating-linear-gradient(0deg, rgba(245,245,241,0.05) 0 1px, transparent 1px 54px), repeating-linear-gradient(90deg, rgba(245,245,241,0.05) 0 1px, transparent 1px 54px)' }} />
      <div style={{ position: 'absolute', inset: 0, transform: `translateY(${drift}px)` }}>
        <ChapterTag text="04 / IN USE" o={M.enter(T, C.Apps + 0.45, C.Apps + 1.05)} accent={accent} />
        <div style={{ position: 'absolute', left: 90, top: 400, ...item(0.4) }}>
          <div style={{ width: 620, height: 360, background: PAPER, borderRadius: 4, boxShadow: shadow, position: 'relative' }}>
            <div style={{ position: 'absolute', left: 44, top: 44, width: 120, height: 76.2 }}><Mark ink={INK} accent={accent} T={T} C={C} idp="c1" /></div>
            <div style={{ position: 'absolute', left: 44, bottom: 74, fontFamily: CP, fontWeight: 600, fontSize: 30, color: INK, whiteSpace: 'nowrap' }}>{cardName}</div>
            <div style={{ position: 'absolute', left: 44, bottom: 40, font: MONO, fontSize: 17, letterSpacing: '0.18em', color: STONE, whiteSpace: 'nowrap' }}>DIRECTOR OF ENGINEERING</div>
            <div style={{ position: 'absolute', right: 44, bottom: 40, fontFamily: CP, fontWeight: 600, fontSize: 18, letterSpacing: '0.3em', color: INK, whiteSpace: 'nowrap' }}>NILESOFT</div>
          </div>
          <div style={{ ...lbl, marginTop: 26 }}>BUSINESS CARD</div>
        </div>
        <div style={{ position: 'absolute', left: 560, top: 850, ...item(0.75) }}>
          <div style={{ width: 430, height: 590, background: PAPER, borderRadius: 4, boxShadow: shadow, position: 'relative' }}>
            <div style={{ position: 'absolute', left: 36, top: 40, width: 84, height: 53.3 }}><Mark ink={INK} accent={accent} T={T} C={C} idp="c2" /></div>
            <div style={{ position: 'absolute', left: 36, top: 160, display: 'grid', gap: 22 }}>
              {[300, 330, 280, 330, 250, 300, 170].map((w, i) => (
                <div key={i} style={{ width: w, height: 9, background: MIST, borderRadius: 2 }} />
              ))}
            </div>
            <div style={{ position: 'absolute', left: 36, bottom: 32, fontFamily: CP, fontWeight: 600, fontSize: 15, letterSpacing: '0.3em', color: STONE, whiteSpace: 'nowrap' }}>NILESOFT</div>
          </div>
          <div style={{ ...lbl, marginTop: 26 }}>LETTERHEAD</div>
        </div>
        <div style={{ position: 'absolute', left: 110, top: 1150, ...item(1.05) }}>
          <div style={{ width: 230, height: 230, background: '#1F1F1D', border: '1px solid rgba(245,245,241,0.14)', borderRadius: 52, boxShadow: shadow, position: 'relative' }}>
            <div style={{ position: 'absolute', left: 55, top: 77, width: 120, height: 76.2 }}><Mark ink={INK_D} accent={accent} T={T} C={C} idp="c3" /></div>
          </div>
          <div style={{ ...lbl, marginTop: 26 }}>PRODUCT ICON</div>
        </div>
      </div>
    </div>
  );
}

function OutroPanel({ T, C, TOT, accent }) {
  const wip = wipeClip(M.draw(T, C.Outro, C.Outro + 0.9));
  const zoom = 1 + 0.05 * M.draw(T, C.Outro + 0.3, TOT + 0.5);
  const rule = 180 * M.draw(T, C.Outro + 1.0, C.Outro + 1.8);
  return (
    <div style={{ position: 'absolute', inset: 0, clipPath: wip, background: PAPER_D }}>
      <div style={{ position: 'absolute', inset: 0, transform: `scale(${zoom})` }}>
        <Lockup T={T} C={C} ink={INK_D} accent={accent} idp="O" animated={false} />
        <div style={{ position: 'absolute', left: 540 - rule / 2, top: 1160, width: rule, height: 3, background: accent }} />
      </div>
    </div>
  );
}

function Piece({ accent, cardName }) {
  const { T, time, CUES: C, authoredTotal: TOT } = useComposition();
  const wp = M.draw(T, C.Invert + 0.15, C.Invert + 1.15);
  const gridO = 0.55 * M.enter(T, C.Grid + 0.05, C.Grid + 0.7) * (1 - M.draw(T, C.Lock + 0.85, C.Lock + 1.7));
  return (
    <div data-screen-label={`t=${Math.floor(time)}s`} style={{ position: 'relative', width: 1080, height: 1920, overflow: 'hidden' }}>
      <div style={{ position: 'absolute', inset: 0, background: PAPER }}>
        <Shot from={-1} to={C.Invert + 1.3}>
          <div style={{ position: 'absolute', inset: 0, opacity: gridO, backgroundPosition: '260px 652px', backgroundImage: 'repeating-linear-gradient(0deg, rgba(19,19,18,0.09) 0 1px, transparent 1px 54px), repeating-linear-gradient(90deg, rgba(19,19,18,0.09) 0 1px, transparent 1px 54px)' }} />
          <Lockup T={T} C={C} ink={INK} accent={accent} idp="L" animated={true} />
        </Shot>
      </div>
      <div style={{ position: 'absolute', inset: 0, clipPath: wipeClip(wp) }}>
        <div style={{ position: 'absolute', inset: 0, background: PAPER_D }} />
        <Shot from={C.Invert - 0.5} to={C.Type + 1.05}>
          <Lockup T={T} C={C} ink={INK_D} accent={accent} idp="D" animated={true} />
        </Shot>
        <Shot from={C.Type} to={C.Color + 1.05}><TypePanel T={T} C={C} accent={accent} /></Shot>
        <Shot from={C.Color} to={C.Apps + 1.05}><ColorPanel T={T} C={C} accent={accent} /></Shot>
        <Shot from={C.Apps} to={C.Outro + 1.05}><AppsPanel T={T} C={C} accent={accent} cardName={cardName} /></Shot>
        <Shot from={C.Outro} to={TOT + 1}><OutroPanel T={T} C={C} TOT={TOT} accent={accent} /></Shot>
      </div>
    </div>
  );
}

window.NilesoftReveal = function NilesoftReveal() {
  const [t, setTweak] = useTweaks(window.TWEAK_DEFAULTS || { motionEditor: true, accent: '#8A8A84', cardName: 'A. HASSAN' });
  return (
    <div style={{ width: '100%', height: '100vh', background: '#161614', display: 'grid', placeItems: 'center' }}>
      <CompositionStage width={1080} height={1920} scenes={window.OM_SCENES} playback={window.OM_PLAYBACK} bg="#FAFAF8">
        <Piece accent={t.accent} cardName={t.cardName} />
      </CompositionStage>
      <TweaksPanel>
        <TweakSection label="Brand" />
        <TweakColor label="Guide accent" value={t.accent} options={['#8A8A84', '#3661C9', '#0B8B8F', '#C06B3E']} onChange={(v) => setTweak('accent', v)} />
        <TweakText label="Card name" value={t.cardName} onChange={(v) => setTweak('cardName', v)} />
        <TweakSection label="Editor" />
        <TweakToggle label="Motion editor" value={t.motionEditor} onChange={(v) => setTweak('motionEditor', v)} />
      </TweaksPanel>
    </div>
  );
};
