// Nilesoft services video — 6 core services, Arabic RTL. 1080×1920, animations-v3.
const { CompositionStage, useComposition, Shot, Easing, animate, clamp } = window;
const { useTweaks, TweaksPanel, TweakSection, TweakColor, TweakToggle } = window;

const PAPER = '#FAFAF8', INK = '#141413', PAPER_D = '#0C0C0B', INK_D = '#F5F5F1', STONE = '#8A8A84';
const CP = "'Chakra Petch', sans-serif";
const AR = "'IBM Plex Sans Arabic', sans-serif";
const MONO = "500 1em ui-monospace, Menlo, monospace";
const M = {
  enter: (T, s, e) => animate({ from: 0, to: 1, start: s, end: e, ease: Easing.easeOutCubic })(T),
  draw:  (T, s, e) => animate({ from: 0, to: 1, start: s, end: e, ease: Easing.easeInOutQuart })(T),
  pop:   (T, s, e) => animate({ from: 0, to: 1, start: s, end: e, ease: Easing.easeOutBack })(T),
};
const SLANT = 0.9 * 1920;
function wipeClip(p) {
  const xt = -(SLANT + 20) + p * (1080 + SLANT + 40);
  return `polygon(0 0, ${xt}px 0, ${xt + SLANT}px 1920px, 0 1920px)`;
}

function MarkStatic({ ink }) {
  return (
    <svg viewBox="0 0 252 160" style={{ position: 'absolute', inset: 0, width: '100%', height: '100%', overflow: 'visible', display: 'block' }}>
      <rect x="188" y="0" width="36" height="36" fill={ink} />
      <rect x="0" y="124" width="36" height="36" fill={ink} />
      <polygon points="0,0 58,0 202,160 144,160" fill={ink} />
      <polygon points="170,70 228,70 252,96.7 252,126 220.4,126" fill={ink} />
      <polygon points="214,134 244,134 252,142.9 252,160 237.4,160" fill={ink} />
    </svg>
  );
}

const SERVICES = [
  { key: 'Presence', kw: 'حضور', name: 'مواقع وصفحات تعريفية', desc: 'بناء مواقع تعكس مستوى شركتك وتترك انطباعاً أولياً قوياً لجذب العملاء وكسب ثقتهم من أول 3 ثوانٍ.' },
  { key: 'Stores', kw: 'استثمار', name: 'متاجر إلكترونية', desc: 'تصميم متاجر إلكترونية تعمل كموظف مبيعات يعمل على مدار 24 ساعة لاستقبال الطلبات وتحويل الزوار لعملاء دائمين.' },
  { key: 'Apps', kw: 'تطبيق', name: 'أنظمة وتطبيقات', desc: 'تطوير تطبيقات مخصصة للهواتف الذكية (iOS & Android) باسم شركتك لبناء ولاء دائم مع العميل وإرسال الإشعارات.' },
  { key: 'Automation', kw: 'أتمتة', name: 'أتمتة وذكاء اصطناعي', desc: 'تحويل العمل اليدوي، والنسخ، واللصق، والمعاملات الورقية إلى لوحة تحكم ذكية ومؤتمتة بالكامل توفر الوقت والمال.' },
  { key: 'System', kw: 'نظام', name: 'إدارة أعمال ذكية', desc: 'تحويل فوضى رسائل الواتساب والطلبات العشوائية إلى نظام برمي منظم لترتيب الفواتير، والعملاء، والعمليات.' },
  { key: 'MVP', kw: 'MVP', name: 'بناء وتطوير الأفكار', desc: 'تحويل الأفكار من مجرد مسودة على ورق إلى نموذج أولي لتطبيق فعلي قابل للإطلاق على المتاجر خلال أسابيع قليلة.' },
];

function GridBg({ line, o }) {
  return <div style={{ position: 'absolute', inset: 0, opacity: o, backgroundImage: `repeating-linear-gradient(0deg, ${line} 0 1px, transparent 1px 54px), repeating-linear-gradient(90deg, ${line} 0 1px, transparent 1px 54px)` }} />;
}

function Progress({ idx, fg, dim, accent }) {
  return (
    <div style={{ position: 'absolute', left: 0, right: 0, bottom: 170, display: 'flex', flexDirection: 'row-reverse', justifyContent: 'center', gap: 16 }}>
      {SERVICES.map((s, i) => {
        const n = i + 1;
        const st = n === idx ? { background: accent } : n < idx ? { background: fg } : { border: `1px solid ${dim}` };
        return <div key={i} style={{ width: 20, height: 20, ...st }} />;
      })}
    </div>
  );
}

function IlloPresence({ T, s, fg, dim, accent }) {
  const p = (d, du = 0.5) => M.enter(T, s + d, s + d + du);
  const dr = (d, du) => M.draw(T, s + d, s + d + du);
  const m = dr(2.0, 0.7);
  const cx = 640 + (114 - 640) * m, cy = 430 + (378 - 430) * m;
  const click = 1 + 0.06 * Math.sin(Math.PI * clamp((T - s - 2.75) / 0.4, 0, 1));
  return (
    <div style={{ position: 'absolute', inset: 0 }}>
      <div style={{ position: 'absolute', inset: 0, border: `3px solid ${fg}`, borderRadius: 10, opacity: p(0.0) }} />
      <div style={{ position: 'absolute', left: 0, right: 0, top: 0, height: 56, borderBottom: `3px solid ${fg}`, opacity: p(0.0) }} />
      {[0, 1, 2].map((i) => <div key={i} style={{ position: 'absolute', left: 24 + i * 24, top: 22, width: 12, height: 12, borderRadius: '50%', background: fg, opacity: p(0.15 + i * 0.08) }} />)}
      <div style={{ position: 'absolute', left: 250, top: 19, width: 240, height: 20, borderRadius: 10, background: dim, opacity: p(0.3) }} />
      <div style={{ position: 'absolute', left: 34, top: 90, width: 652, height: 140, background: accent, opacity: 0.9 * p(0.4, 0.2), clipPath: `inset(0 ${(1 - dr(0.45, 0.6)) * 100}% 0 0)` }} />
      <div style={{ position: 'absolute', left: 34, top: 262, width: 430, height: 16, background: dim, opacity: p(0.75) }} />
      <div style={{ position: 'absolute', left: 34, top: 294, width: 300, height: 16, background: dim, opacity: p(0.85) }} />
      <div style={{ position: 'absolute', left: 34, top: 350, width: 160, height: 56, background: fg, borderRadius: 4, opacity: p(1.0), transform: `scale(${click})` }} />
      <div style={{ position: 'absolute', left: cx, top: cy, width: 16, height: 16, background: accent, opacity: p(1.9) }} />
    </div>
  );
}

function IlloStores({ T, s, fg, dim, accent }) {
  const p = (d, du = 0.5) => M.enter(T, s + d, s + d + du);
  const dr = (d, du) => M.draw(T, s + d, s + d + du);
  return (
    <div style={{ position: 'absolute', inset: 0 }}>
      {[0, 1].map((i) => (
        <div key={i} style={{ position: 'absolute', left: 30 + i * 230, top: 50, width: 200, height: 270, border: `3px solid ${fg}`, borderRadius: 8, opacity: p(0.05 + i * 0.15), transform: `scale(${0.85 + 0.15 * M.pop(T, s + 1.0 + i * 0.15, s + 1.5 + i * 0.15)})` }}>
          <div style={{ position: 'absolute', left: 21, top: 21, width: 152, height: 120, background: dim, borderRadius: 4 }} />
          <div style={{ position: 'absolute', left: 21, top: 168, width: 90, height: 16, background: fg }} />
          <div style={{ position: 'absolute', right: 21, bottom: 21, width: 44, height: 32, background: accent, opacity: p(0.45 + i * 0.15) }} />
        </div>
      ))}
      <div style={{ position: 'absolute', left: 505, top: 400, width: 185, height: 3, background: fg, transformOrigin: 'left', transform: `scaleX(${dr(0.35, 0.4)})` }} />
      {[120, 190, 260].map((h, i) => (
        <div key={i} style={{ position: 'absolute', left: 512 + i * 60, bottom: 63, width: 40, height: h, transformOrigin: 'bottom', transform: `scaleY(${dr(0.5 + i * 0.15, 0.6)})` }}>
          <div style={{ position: 'absolute', inset: 0, border: `3px solid ${fg}` }} />
          <div style={{ position: 'absolute', left: -3, top: -3, right: -3, height: 14, background: accent, opacity: p(1.2 + i * 0.1, 0.3) }} />
        </div>
      ))}
    </div>
  );
}

function IlloApps({ T, s, fg, dim, accent }) {
  const p = (d, du = 0.5) => M.enter(T, s + d, s + d + du);
  const u = (() => { const v = (T - s - 2.2) / 1.4; return v - Math.floor(v); })();
  const ring = p(1.3, 0.3);
  return (
    <div style={{ position: 'absolute', inset: 0 }}>
      <div style={{ position: 'absolute', left: 245, top: 8, width: 230, height: 444, border: `3px solid ${fg}`, borderRadius: 30, opacity: p(0.0) }} />
      <div style={{ position: 'absolute', left: 328, top: 26, width: 64, height: 6, borderRadius: 3, background: dim, opacity: p(0.1) }} />
      {Array.from({ length: 12 }).map((_, i) => {
        const c = i % 3, r = (i / 3) | 0;
        const sc = 0.5 + 0.5 * M.pop(T, s + 0.25 + i * 0.055, s + 0.65 + i * 0.055);
        return <div key={i} style={{ position: 'absolute', left: 279 + c * 60, top: 70 + r * 60, width: 44, height: 44, borderRadius: 8, background: i === 2 ? accent : dim, opacity: p(0.25 + i * 0.055, 0.3), transform: `scale(${sc})` }} />;
      })}
      <div style={{ position: 'absolute', left: 424, top: 56, width: 20, height: 20, borderRadius: '50%', background: fg, opacity: p(1.15), transform: `scale(${0.4 + 0.6 * M.pop(T, s + 1.15, s + 1.5)})` }} />
      <div style={{ position: 'absolute', left: 414, top: 46, width: 40, height: 40, borderRadius: '50%', border: `3px solid ${accent}`, opacity: ring * (1 - u), transform: `scale(${0.5 + 1.6 * u})` }} />
    </div>
  );
}

function IlloAutomation({ T, s, fg, dim, accent }) {
  const p = (d, du = 0.5) => M.enter(T, s + d, s + d + du);
  const dr = (d, du) => M.draw(T, s + d, s + d + du);
  const cyc = (per, off) => { const v = (T - s - off) / per; return v - Math.floor(v); };
  const papers = [{ x: 24, y: 100, r: -12 }, { x: 64, y: 220, r: 9 }, { x: 30, y: 330, r: -5 }];
  const pu = cyc(1.6, 0);
  const node = 1 + 0.15 * Math.sin(2 * Math.PI * cyc(1.6, 0.8));
  return (
    <div style={{ position: 'absolute', inset: 0 }}>
      {papers.map((pp, i) => (
        <div key={i} style={{ position: 'absolute', left: pp.x, top: pp.y, width: 74, height: 94, border: `3px solid ${dim}`, borderRadius: 4, opacity: p(0.05 + i * 0.12), transform: `rotate(${pp.r}deg) translateY(${4 * Math.sin(2 * Math.PI * cyc(2.6, i * 0.4))}px)` }} />
      ))}
      <div style={{ position: 'absolute', left: 140, top: 250, width: 190, height: 3, background: fg, transformOrigin: 'left', transform: `scaleX(${dr(0.35, 0.5)})` }} />
      <div style={{ position: 'absolute', left: 330, top: 207, width: 90, height: 90, border: `3px solid ${fg}`, opacity: p(0.6) }}>
        <div style={{ position: 'absolute', left: 28, top: 28, width: 28, height: 28, background: accent, transform: `scale(${node})` }} />
      </div>
      <div style={{ position: 'absolute', left: 420, top: 250, width: 70, height: 3, background: fg, transformOrigin: 'left', transform: `scaleX(${dr(0.85, 0.3)})` }} />
      <div style={{ position: 'absolute', left: 490, top: 150, width: 210, height: 200, border: `3px solid ${fg}`, borderRadius: 8, opacity: p(1.0) }}>
        {[0, 1, 2, 3].map((i) => (
          <div key={i} style={{ position: 'absolute', left: 22 + (i % 2) * 94, top: 22 + ((i / 2) | 0) * 84, width: 80, height: 72, background: dim }}>
            <div style={{ position: 'absolute', inset: 0, background: accent, opacity: 0.9 * p(1.3 + i * 0.2, 0.35) }} />
          </div>
        ))}
      </div>
      <div style={{ position: 'absolute', left: 140 + 350 * pu, top: 244, width: 14, height: 14, background: accent, opacity: p(0.7) * (pu < 0.04 || pu > 0.96 ? 0 : 1) }} />
    </div>
  );
}

function IlloSystem({ T, s, fg, dim, accent }) {
  const p = (d, du = 0.5) => M.enter(T, s + d, s + d + du);
  const dr = (d, du) => M.draw(T, s + d, s + d + du);
  const bubbles = [{ x: 36, y: 60, r: -10, w: 110, h: 48 }, { x: 120, y: 170, r: 12, w: 90, h: 44 }, { x: 40, y: 270, r: -6, w: 120, h: 48 }, { x: 130, y: 360, r: 8, w: 84, h: 40 }];
    return (
    <div style={{ position: 'absolute', inset: 0 }}>
      {bubbles.map((b, i) => {
        const mv = dr(0.4 + i * 0.12, 0.7);
        const fade = 1 - M.enter(T, s + 1.0 + i * 0.12, s + 1.2 + i * 0.12);
        return <div key={i} style={{ position: 'absolute', left: b.x, top: b.y, width: b.w, height: b.h, border: `3px solid ${dim}`, borderRadius: 14, opacity: p(0.0 + i * 0.08) * fade, transform: `translate(${(215 - b.x) * mv * 0.85}px, ${(60 + i * 104 - b.y) * mv}px) rotate(${b.r * (1 - mv)}deg)` }} />;
      })}
      {[0, 1, 2, 3].map((i) => {
        const v = p(0.65 + i * 0.13);
        return (
          <div key={i} style={{ position: 'absolute', left: 215, top: 60 + i * 104, width: 420, height: 72, border: `3px solid ${fg}`, borderRadius: 6, opacity: v, transform: `translateY(${20 * (1 - v)}px)` }}>
            <div style={{ position: 'absolute', left: 24, top: 26, width: 190, height: 14, background: dim }} />
            <div style={{ position: 'absolute', right: 24, top: 22, width: 22, height: 22, background: accent, transform: `scale(${M.pop(T, s + 1.3 + i * 0.13, s + 1.7 + i * 0.13)})` }} />
          </div>
        );
      })}
    </div>
  );
}

function IlloMVP({ T, s, fg, dim, accent }) {
  const p = (d, du = 0.5) => M.enter(T, s + d, s + d + du);
  const dr = (d, du) => M.draw(T, s + d, s + d + du);
  const cyc = (per, off) => { const v = (T - s - 1.6 - off) / per; return v - Math.floor(v); };
  return (
    <div style={{ position: 'absolute', inset: 0 }}>
      <div style={{ position: 'absolute', left: 30, top: 70, width: 240, height: 320, border: `3px dashed ${dim}`, borderRadius: 8, opacity: p(0.05) }}>
        {[150, 110, 170].map((w, i) => <div key={i} style={{ position: 'absolute', left: 28, top: 40 + i * 30, width: w, height: 12, background: dim, opacity: p(0.2 + i * 0.08) }} />)}
      </div>
      <div style={{ position: 'absolute', left: 290, top: 228, width: 110, height: 3, background: fg, transformOrigin: 'left', transform: `scaleX(${dr(0.5, 0.4)})` }} />
      <div style={{ position: 'absolute', left: 400, top: 219, width: 0, height: 0, borderTop: '10px solid transparent', borderBottom: '10px solid transparent', borderLeft: `16px solid ${fg}`, opacity: p(0.85, 0.25) }} />
      <div style={{ position: 'absolute', left: 430, top: 110, width: 220, height: 220, border: `3px solid ${fg}`, borderRadius: 44, opacity: p(1.0), transform: `scale(${0.7 + 0.3 * M.pop(T, s + 1.0, s + 1.5)})` }}>
        <div style={{ position: 'absolute', left: 40, top: 66, width: 140, height: 89 }}><MarkStatic ink={fg} /></div>
      </div>
      <div style={{ position: 'absolute', left: 430, top: 372, width: 220, height: 8, background: dim, opacity: p(1.2) }} />
      <div style={{ position: 'absolute', left: 430, top: 372, width: 220, height: 8, background: accent, transformOrigin: 'left', transform: `scaleX(${dr(1.3, 1.2)})` }} />
      {[470, 540, 610].map((x, i) => {
        const u = cyc(1.3, i * 0.35);
        return <div key={i} style={{ position: 'absolute', left: x, top: 90 - 70 * u, width: 6, height: 24, background: accent, opacity: p(1.5) * (1 - u) }} />;
      })}
    </div>
  );
}

const ILLOS = { Presence: IlloPresence, Stores: IlloStores, Apps: IlloApps, Automation: IlloAutomation, System: IlloSystem, MVP: IlloMVP };

function ServicePanel({ T, s, e, idx, dark, kw, name, desc, accent, kind }) {
  const wip = wipeClip(M.draw(T, s, s + 0.85));
  const drift = 16 - 34 * M.draw(T, s + 0.15, e + 0.5);
  const bg = dark ? PAPER_D : PAPER;
  const fg = dark ? INK_D : INK;
  const sub = dark ? 'rgba(245,245,241,0.78)' : '#52524D';
  const dim = dark ? 'rgba(245,245,241,0.3)' : 'rgba(20,20,19,0.3)';
  const en = (d) => M.enter(T, s + d, s + d + 0.6);
  const rise = (v) => `translateY(${28 * (1 - v)}px)`;
  const IlloC = ILLOS[kind];
  return (
    <div style={{ position: 'absolute', inset: 0, clipPath: wip, background: bg }}>
      <GridBg line={dark ? 'rgba(245,245,241,0.05)' : 'rgba(19,19,18,0.07)'} o={0.5} />
      <div style={{ position: 'absolute', inset: 0, transform: `translateY(${drift}px)` }}>
        <div dir="ltr" style={{ position: 'absolute', right: 90, top: 170, display: 'flex', alignItems: 'center', gap: 18, opacity: en(0.4) }}>
          <div style={{ font: MONO, fontSize: 26, letterSpacing: '0.3em', color: STONE, whiteSpace: 'nowrap' }}>{'0' + idx + ' / 06'}</div>
          <div style={{ width: 14, height: 14, background: accent }} />
        </div>
        <div dir="rtl" style={{ position: 'absolute', right: 84, top: 400, fontFamily: kw === 'MVP' ? CP : AR, fontWeight: 700, fontSize: 150, lineHeight: 1.25, color: fg, whiteSpace: 'nowrap', opacity: en(0.5), transform: rise(en(0.5)) }}>{kw}</div>
        <div style={{ position: 'absolute', right: 90, top: 648, width: 74, height: 12, background: accent, opacity: en(0.62), transform: rise(en(0.62)) }} />
        <div dir="rtl" style={{ position: 'absolute', right: 90, top: 692, fontFamily: AR, fontWeight: 600, fontSize: 58, lineHeight: 1.5, color: fg, whiteSpace: 'nowrap', opacity: en(0.72), transform: rise(en(0.72)) }}>{name}</div>
        <div dir="rtl" style={{ position: 'absolute', right: 90, top: 810, width: 880, fontFamily: AR, fontWeight: 500, fontSize: 37, lineHeight: 1.95, color: sub, textAlign: 'right', opacity: en(0.9), transform: rise(en(0.9)) }}>{desc}</div>
        <div style={{ position: 'absolute', left: 180, top: 1120, width: 720, height: 460, opacity: en(0.95), transform: rise(en(0.95)) }}>
          <IlloC T={T} s={s + 0.95} fg={fg} dim={dim} accent={accent} />
        </div>
        <div style={{ opacity: en(1.05) }}><Progress idx={idx} fg={fg} dim={dim} accent={accent} /></div>
      </div>
    </div>
  );
}

function IntroPanel({ T, C, accent }) {
  const en = (d) => M.enter(T, C.Intro + d, C.Intro + d + 0.65);
  const rise = (v) => `translateY(${30 * (1 - v)}px)`;
  const drift = 12 - 24 * M.draw(T, C.Intro, C.Presence + 0.5);
  return (
    <div style={{ position: 'absolute', inset: 0, background: PAPER }}>
      <GridBg line="rgba(19,19,18,0.08)" o={0.55 * en(0.05)} />
      <div style={{ position: 'absolute', inset: 0, transform: `translateY(${drift}px)` }}>
        <div style={{ position: 'absolute', left: 0, right: 0, top: 184, textAlign: 'center', font: MONO, fontSize: 24, letterSpacing: '0.34em', color: STONE, whiteSpace: 'nowrap', opacity: en(0.2) }}>NILESOFT / SERVICES</div>
        <div style={{ position: 'absolute', left: 410, top: 330, width: 260, height: 165, opacity: en(0.35), transform: rise(en(0.35)) }}><MarkStatic ink={INK} /></div>
        <div style={{ position: 'absolute', left: 0, right: 0, top: 620, textAlign: 'center', fontFamily: CP, fontWeight: 600, fontSize: 330, lineHeight: 1, color: INK, opacity: en(0.5), transform: rise(en(0.5)) }}>06</div>
        <div style={{ position: 'absolute', left: 490, top: 1010, width: 100, height: 12, background: accent, opacity: en(0.62) }} />
        <div dir="rtl" style={{ position: 'absolute', left: 0, right: 0, top: 1070, textAlign: 'center', fontFamily: AR, fontWeight: 700, fontSize: 100, lineHeight: 1.4, color: INK, whiteSpace: 'nowrap', opacity: en(0.7), transform: rise(en(0.7)) }}>خدمات أساسية</div>
      </div>
    </div>
  );
}

function OutroPanel({ T, C, TOT, accent }) {
  const wip = wipeClip(M.draw(T, C.Outro, C.Outro + 0.85));
  const zoom = 1 + 0.05 * M.draw(T, C.Outro + 0.3, TOT + 0.5);
  const rule = 180 * M.draw(T, C.Outro + 0.9, C.Outro + 1.7);
  return (
    <div style={{ position: 'absolute', inset: 0, clipPath: wip, background: PAPER_D }}>
      <div style={{ position: 'absolute', inset: 0, transform: `scale(${zoom})` }}>
        <div style={{ position: 'absolute', left: 260, top: 610, width: 560, height: 355.5 }}><MarkStatic ink={INK_D} /></div>
        <div style={{ position: 'absolute', left: 0, right: 0, top: 1030, textAlign: 'center', fontFamily: CP, fontWeight: 600, fontSize: 84, letterSpacing: '0.42em', paddingLeft: '0.42em', color: INK_D, whiteSpace: 'nowrap' }}>NILESOFT</div>
        <div style={{ position: 'absolute', left: 540 - rule / 2, top: 1200, width: rule, height: 3, background: accent }} />
      </div>
    </div>
  );
}

function Piece({ accent }) {
  const { T, time, CUES: C, authoredTotal: TOT } = useComposition();
  return (
    <div data-screen-label={`t=${Math.floor(time)}s`} style={{ position: 'relative', width: 1080, height: 1920, overflow: 'hidden', background: PAPER }}>
      <Shot from={-1} to={C.Presence + 1.0}><IntroPanel T={T} C={C} accent={accent} /></Shot>
      {SERVICES.map((sv, i) => {
        const s = C[sv.key];
        const e = i < 5 ? C[SERVICES[i + 1].key] : C.Outro;
        return (
          <Shot key={sv.key} from={s} to={e + 1.0}>
            <ServicePanel T={T} s={s} e={e} idx={i + 1} dark={i % 2 === 0} kw={sv.kw} name={sv.name} desc={sv.desc} accent={accent} kind={sv.key} />
          </Shot>
        );
      })}
      <Shot from={C.Outro} to={TOT + 1}><OutroPanel T={T} C={C} TOT={TOT} accent={accent} /></Shot>
    </div>
  );
}

window.NilesoftServices = function NilesoftServices() {
  const [t, setTweak] = useTweaks(window.TWEAK_DEFAULTS || { motionEditor: true, accent: '#C06B3E' });
  return (
    <div style={{ width: '100%', height: '100vh', background: '#161614', display: 'grid', placeItems: 'center' }}>
      <CompositionStage width={1080} height={1920} scenes={window.OM_SCENES} playback={window.OM_PLAYBACK} bg="#FAFAF8">
        <Piece accent={t.accent} />
      </CompositionStage>
      <TweaksPanel>
        <TweakSection label="Brand" />
        <TweakColor label="Accent" value={t.accent} options={['#C06B3E', '#8A8A84', '#3661C9', '#0B8B8F']} onChange={(v) => setTweak('accent', v)} />
        <TweakSection label="Editor" />
        <TweakToggle label="Motion editor" value={t.motionEditor} onChange={(v) => setTweak('motionEditor', v)} />
      </TweaksPanel>
    </div>
  );
};
